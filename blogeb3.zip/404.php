<?php get_header(); ?>

<main>
    <h3 style="font-size: 3em; width: 100%; text-align: center; padding-top: 180px; padding-bottom: 400px">Erro 404</h3>
</main>

<?php get_footer(); ?>